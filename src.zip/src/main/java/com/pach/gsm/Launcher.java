package com.pach.gsm;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args){
        App.main(args);
    }
}
